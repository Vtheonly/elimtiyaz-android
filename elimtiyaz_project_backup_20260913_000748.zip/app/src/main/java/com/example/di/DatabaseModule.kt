package com.example.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.room.Room
import androidx.work.Configuration
import androidx.work.WorkManager
import com.example.infrastructure.room.AcademicClassDao
import com.example.infrastructure.room.AssessmentDao
import com.example.infrastructure.room.AttendanceDao
import com.example.infrastructure.room.AuditLogDao
import com.example.infrastructure.room.ClassSubjectDao
import com.example.infrastructure.room.DepartmentDao
import com.example.infrastructure.room.ElImtiyazDatabase
import com.example.infrastructure.room.ExpenseDao
import com.example.infrastructure.room.HomeworkDao
import com.example.infrastructure.room.InstallmentDao
import com.example.infrastructure.room.LedgerEntryDao
import com.example.infrastructure.room.NotificationDao
import com.example.infrastructure.room.ParentDao
import com.example.infrastructure.room.PaymentDao
import com.example.infrastructure.room.PersonnelDao
import com.example.infrastructure.room.PricingConfigDao
import com.example.infrastructure.room.ReleveEntryDao
import com.example.infrastructure.room.StudentDao
import com.example.infrastructure.room.SubjectDao
import com.example.infrastructure.room.TripLogDao
import com.example.infrastructure.room.VehicleDao
import com.example.infrastructure.room.RoutingStopDao
import com.example.infrastructure.room.WorkflowRunDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Database + WorkManager + DataStore DI module.
 *
 * Room is the **local source of truth** for this build. The database mirrors
 * the desktop's Supabase schema field-by-field so business logic and financial
 * calculations produce identical numbers on both platforms.
 *
 * T-046 / ARCH-004 — MIGRATION DISCIPLINE: the previous destructive-migration
 * fallback (the Room builder flag this task removed) silently WIPED all user
 * data on any
 * schema bump whose explicit migration was forgotten. The fallback is now
 * GONE: the full explicit chain (v3→v12) is registered below, and a missing
 * migration fails LOUDLY (IllegalStateException at open time) instead of
 * destroying the local source of truth. Every future schema bump MUST ship
 * a new `MIGRATION_X_Y` in [ElImtiyazDatabase.Companion] and register it
 * here in the same change (pinned by DatabaseMigrationDisciplineT046Test).
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): ElImtiyazDatabase =
        Room.databaseBuilder(context, ElImtiyazDatabase::class.java, "el_imtiyaz.db")
            // TIER 2 R12 — register MIGRATION_4_5 so users don't lose their
            // data when upgrading. The migration adds the `paymentPlan` column
            // to the `students` table with default `'tranches'` (matching the
            // desktop's default for imported students without an explicit
            // `payment_plan` value).
            //
            // TIER 3 R18 — register MIGRATION_5_6 so the `finalSpentAmount`
            // column is added to the `expenses` table. The column stores the
            // actual spent amount confirmed by the proof scan at settlement
            // time — previously `settleProof()` accepted the parameter but
            // silently dropped it.
            .addMigrations(
                ElImtiyazDatabase.MIGRATION_3_4,
                ElImtiyazDatabase.MIGRATION_4_5,
                ElImtiyazDatabase.MIGRATION_5_6,
                ElImtiyazDatabase.MIGRATION_6_7,
                ElImtiyazDatabase.MIGRATION_7_8,
                ElImtiyazDatabase.MIGRATION_8_9,
                ElImtiyazDatabase.MIGRATION_9_10,
                // Vault §06.02 (iteration 2) — per-COMPONENT coefficients for
                // the subject-average recipe. Adds three REAL columns to
                // `subjects` (admin-configurable per-component weights) and
                // the same three columns to `assessments` (per-row snapshot
                // at grade-entry time; archived years stay immutable).
                // Defaults (1.0, 1.0, 2.0) preserve the historical
                // (D1 + D2 + 2×Ex) / 4 recipe bit-identically, so existing
                // GPAs do not move by a single centime after the migration.
                ElImtiyazDatabase.MIGRATION_10_11,
                // T-054 (WEAK-008): workflow_runs.trigger — the REAL trigger of
                // each pulled run (was hardcoded "manual" at the mapping
                // boundary). Default 'manual' preserves existing rows' meaning.
                ElImtiyazDatabase.MIGRATION_11_12,
                // T-039 / NOTIF-105: notifications.targetRole — lets the pull
                // layer evict stale role-broadcasts after a role change.
                // Nullable, no default: direct/tenant broadcasts keep NULL.
                ElImtiyazDatabase.MIGRATION_12_13,
                // T-181 (T-173b / NOTIF-200): notifications.dismissedAt — the
                // server's dismissal timestamp, so the pull layer can evict
                // rows resolved server-side since the last pull (pre-T-181
                // they lingered in Room forever). Nullable, no default.
                ElImtiyazDatabase.MIGRATION_13_14,
            )
            // T-046 / ARCH-004: NO destructive fallback. A missing migration
            // now fails LOUDLY (IllegalStateException) instead of wiping the
            // local source of truth. If Room throws "A migration from X to Y
            // was required but not found" the fix is an explicit migration —
            // never re-add the fallback.
            .build()

    // ── Original cache DAOs (kept for sync layer) ──
    @Provides @Singleton
    fun provideParentCacheDao(db: ElImtiyazDatabase) = db.parentCacheDao()

    @Provides @Singleton
    fun provideStudentCacheDao(db: ElImtiyazDatabase) = db.studentCacheDao()

    @Provides @Singleton
    fun providePaymentCacheDao(db: ElImtiyazDatabase) = db.paymentCacheDao()

    @Provides @Singleton
    fun provideLedgerCacheDao(db: ElImtiyazDatabase) = db.ledgerCacheDao()

    @Provides @Singleton
    fun provideSyncQueueDao(db: ElImtiyazDatabase) = db.syncQueueDao()

    // ── Local source-of-truth DAOs ──
    @Provides @Singleton
    fun provideParentDao(db: ElImtiyazDatabase): ParentDao = db.parentDao()

    @Provides @Singleton
    fun provideStudentDao(db: ElImtiyazDatabase): StudentDao = db.studentDao()

    @Provides @Singleton
    fun provideAcademicClassDao(db: ElImtiyazDatabase): AcademicClassDao = db.academicClassDao()

    @Provides @Singleton
    fun provideSubjectDao(db: ElImtiyazDatabase): SubjectDao = db.subjectDao()

    @Provides @Singleton
    fun provideAttendanceDao(db: ElImtiyazDatabase): AttendanceDao = db.attendanceDao()

    @Provides @Singleton
    fun provideAssessmentDao(db: ElImtiyazDatabase): AssessmentDao = db.assessmentDao()

    @Provides @Singleton
    fun provideHomeworkDao(db: ElImtiyazDatabase): HomeworkDao = db.homeworkDao()

    @Provides @Singleton
    fun providePaymentDao(db: ElImtiyazDatabase): PaymentDao = db.paymentDao()

    @Provides @Singleton
    fun provideInstallmentDao(db: ElImtiyazDatabase): InstallmentDao = db.installmentDao()

    @Provides @Singleton
    fun provideLedgerEntryDao(db: ElImtiyazDatabase): LedgerEntryDao = db.ledgerEntryDao()

    @Provides @Singleton
    fun provideExpenseDao(db: ElImtiyazDatabase): ExpenseDao = db.expenseDao()

    @Provides @Singleton
    fun providePersonnelDao(db: ElImtiyazDatabase): PersonnelDao = db.personnelDao()

    @Provides @Singleton
    fun provideDepartmentDao(db: ElImtiyazDatabase): DepartmentDao = db.departmentDao()

    @Provides @Singleton
    fun providePricingConfigDao(db: ElImtiyazDatabase): PricingConfigDao = db.pricingConfigDao()

    @Provides @Singleton
    fun provideNotificationDao(db: ElImtiyazDatabase): NotificationDao = db.notificationDao()

    @Provides @Singleton
    fun provideAuditLogDao(db: ElImtiyazDatabase): AuditLogDao = db.auditLogDao()

    @Provides @Singleton
    fun provideTripLogDao(db: ElImtiyazDatabase): TripLogDao = db.tripLogDao()

    @Provides @Singleton
    fun provideVehicleDao(db: ElImtiyazDatabase): VehicleDao = db.vehicleDao()

    @Provides @Singleton
    fun provideRoutingStopDao(db: ElImtiyazDatabase): RoutingStopDao = db.routingStopDao()

    @Provides @Singleton
    fun provideClassSubjectDao(db: ElImtiyazDatabase): ClassSubjectDao = db.classSubjectDao()

    @Provides @Singleton
    fun provideReleveEntryDao(db: ElImtiyazDatabase): ReleveEntryDao = db.releveEntryDao()

    @Provides @Singleton
    fun provideWorkflowRunDao(db: ElImtiyazDatabase): WorkflowRunDao = db.workflowRunDao()

    @Provides @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager =
        WorkManager.getInstance(context)

    /**
     * Provide the singleton [DataStore<Preferences>] for app settings.
     */
    @Provides @Singleton
    fun provideSettingsDataStore(
        @ApplicationContext context: Context,
    ): DataStore<Preferences> = PreferenceDataStoreFactory.create(
        scope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
        produceFile = { java.io.File(context.filesDir, "datastore/el_imtiyaz_settings.preferences_pb") },
    )
}
